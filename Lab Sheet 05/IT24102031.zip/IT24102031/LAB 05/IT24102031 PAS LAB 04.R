setwd("C:\\Users\\it24102031\\Desktop\\IT24102031\\LAB 05")
getwd()
delivery_times <- read.table("Exercise - Lab 05.txt",header=TRUE)
head(delivery_times)

times <- as.numeric(delivery_times$'Delivery_Time_(minutes)'
)
breaks <- seq(20, 70, by = 5) 

hist(times, 
     breaks = breaks, 
     right = FALSE,     
     col = "darkblue", 
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     border = "yellow")

hist_data <- hist(times, breaks = breaks, right = FALSE, plot = FALSE)
cum_freq <- cumsum(hist_data$counts)
midpoints <- hist_data$breaks[-1]

plot(midpoints, cum_freq, 
     type = "o", col = "red", 
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")

